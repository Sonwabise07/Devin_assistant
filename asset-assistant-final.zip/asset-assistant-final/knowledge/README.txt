Add only approved asset-management/project Markdown documents (*.md) here.
The assistant retrieves matching passages and cites the filename and heading.
This folder contains no project policy documents by default.

$ErrorActionPreference = 'Stop'
if (-not (Test-Path '.env')) { throw 'Copy .env.example to .env and set MSSQL_SA_PASSWORD first.' }
$line = Get-Content '.env' | Where-Object { $_ -match '^MSSQL_SA_PASSWORD=' } | Select-Object -First 1
if (-not $line) { throw 'MSSQL_SA_PASSWORD is missing from .env.' }
$password = ($line -replace '^MSSQL_SA_PASSWORD=', '').Trim().Trim('"').Trim("'")
docker compose up -d sqlserver
$ready = $false
for ($i = 0; $i -lt 40; $i++) {
  docker exec asset-assistant-sql /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P $password -C -b -f 65001 -Q 'SELECT 1' *> $null
  if ($LASTEXITCODE -eq 0) { $ready = $true; break }
  Start-Sleep -Seconds 3
}
if (-not $ready) { throw 'SQL Server did not become ready. Check `docker compose logs sqlserver`.' }
docker exec asset-assistant-sql /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P $password -C -b -f 65001 -i /seed/01_create_mock_db.sql
docker exec asset-assistant-sql /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P $password -C -b -f 65001 -i /seed/02_assistant_schema.sql
Write-Host 'Mock database and assistant history schema created. Run this script only once per fresh volume.'

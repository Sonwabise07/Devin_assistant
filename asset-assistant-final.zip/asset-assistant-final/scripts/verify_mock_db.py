"""Check that the local seed is loaded and report known mock-data coverage gaps."""
from app.config import settings
from app.db import SqlServer, DatabaseUnavailable


def main():
    db = SqlServer(settings.asset_db)
    checks = {
        "dbo.Assets": "SELECT COUNT_BIG(1) AS Total FROM dbo.Assets",
        "dbo.Employees": "SELECT COUNT_BIG(1) AS Total FROM dbo.Employees",
        "dbo.Departments": "SELECT COUNT_BIG(1) AS Total FROM dbo.Departments",
        "dbo.Locations": "SELECT COUNT_BIG(1) AS Total FROM dbo.Locations",
        "dbo.Storerooms": "SELECT COUNT_BIG(1) AS Total FROM dbo.Storerooms",
        "current assignments": "SELECT COUNT_BIG(1) AS Total FROM dbo.AssetAssignments WHERE ReturnedAt IS NULL",
        "dbo.AssetHistory": "SELECT COUNT_BIG(1) AS Total FROM dbo.AssetHistory",
        "dbo.AssetTransfers": "SELECT COUNT_BIG(1) AS Total FROM dbo.AssetTransfers",
    }
    try:
        ping = db.ping()
    except DatabaseUnavailable as exc:
        raise SystemExit(str(exc))
    print(f"Connected to database: {ping.get('DatabaseName')}")
    for name, sql in checks.items():
        try:
            count = db.query(sql)[0]["Total"]
            print(f"{name}: {count}")
        except Exception as exc:
            print(f"{name}: ERROR ({exc})")
            raise
    quality = db.query("""
        SELECT
          SUM(CASE WHEN a.LocationId IS NOT NULL AND l.LocationId IS NULL THEN 1 ELSE 0 END) AS AssetsWithUnmatchedLocationId,
          SUM(CASE WHEN a.DepartmentId IS NOT NULL AND d.DepartmentId IS NULL THEN 1 ELSE 0 END) AS AssetsWithUnmatchedDepartmentId,
          SUM(CASE WHEN a.WarrantyEnd IS NULL THEN 1 ELSE 0 END) AS AssetsWithoutWarrantyEnd
        FROM dbo.Assets AS a
        LEFT JOIN dbo.Locations AS l ON l.LocationId = a.LocationId
        LEFT JOIN dbo.Departments AS d ON d.DepartmentId = a.DepartmentId
    """)[0]
    print("Data quality indicators (not necessarily errors):")
    for key, value in quality.items(): print(f"  {key}: {value}")
    print("Use this report alongside direct SQL expected results; this small seed is for functional testing, not load testing.")

if __name__ == "__main__":
    main()

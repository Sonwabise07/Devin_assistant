#!/usr/bin/env bash
set -euo pipefail
if [[ ! -f .env ]]; then echo 'Copy .env.example to .env and set MSSQL_SA_PASSWORD first.' >&2; exit 1; fi
set -a; source .env; set +a
docker compose up -d sqlserver
for _ in $(seq 1 40); do
  if docker exec asset-assistant-sql /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$MSSQL_SA_PASSWORD" -C -b -f 65001 -Q 'SELECT 1' >/dev/null 2>&1; then break; fi
  sleep 3
done
docker exec asset-assistant-sql /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$MSSQL_SA_PASSWORD" -C -b -f 65001 -i /seed/01_create_mock_db.sql
docker exec asset-assistant-sql /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P "$MSSQL_SA_PASSWORD" -C -b -f 65001 -i /seed/02_assistant_schema.sql
echo 'Mock database and assistant history schema created. Run this script only once per fresh volume.'

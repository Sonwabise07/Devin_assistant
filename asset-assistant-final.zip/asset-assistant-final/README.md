# Asset Assistant — local testing release (v1)

A standalone, local-first chatbot wired to the **main-system-shaped mock data** from the supplied `AssetManagementWorking 1.sql`. It exposes a stable `/api/v1` contract for later integration with the main application.

> **Development only.** The bundled SQL seed is mock data. Do not point this package at production. The app binds to `127.0.0.1` by default and accepts no client-supplied owner identity.

## What works in this release

- SQL Server-backed, read-only answers from the main-system `dbo` tables: asset counts and filters, grouped breakdowns, asset lookup, current assignments, warranty dates, asset history, transfers, recorded purchase-cost summaries, and monthly acquisition counts/costs.
- Follow-ups such as “How many assets?” → “How many are laptops?”, “Show warranty expiries” → “Only next quarter”, “Tell me about AST-2026-001” → “Show its history”, “What about Durban?”, and “Make that a chart”.
- A constrained local Ollama planner may translate harder questions into a typed query plan. It cannot write or execute SQL. Every SQL statement is an application-owned template with parameterized values and allowlisted fields/joins. The deterministic parser remains as a fallback.
- Tables, source/evidence labels, and a simple bar chart for grouped results.
- Approved project-document retrieval from Markdown files in `knowledge/`, with source citations. If no document supports an answer, the assistant says so.
- Optional saved conversations in a separate `assistant` schema: list, reopen, stop saving future turns, and delete. Saving is opt-in by default. The local owner is set on the server as `LOCAL_USER_ID`; clients cannot submit an owner ID.
- Versioned API: health, catalog, chat, and conversation list/load/delete routes.

## Mock database facts and limits

The uploaded script contains two different asset models. This release loads the full script into an isolated database named `AssetManagement_AA_Test`, but queries only the main-app-shaped `dbo` tables; it does not use the older `asset_management` model or its reporting views as a second asset source. The source has 14 asset rows, 6 employees, 4 departments, 3 locations, 2 assignment rows, 7 history rows, and 1 transfer row. Some asset assignment, department, location, and history data is sparse or inconsistent, so results include mock-data/coverage warnings where relevant. Counts and joins use distinct asset IDs to avoid join multiplication.

The portable seed script is based on the uploaded SQL file. It removes its machine-specific Windows MDF/LDF paths, uses the isolated test database name, targets SQL Server 2022 compatibility level 160, and omits a SQL Server 2025-only database option. It deliberately fails if the test database already exists instead of dropping data.

## Windows quick start (Docker Desktop)

1. Extract this folder and open PowerShell in it.
2. Copy `.env.example` to `.env`. Change `MSSQL_SA_PASSWORD` and the matching `PWD=` in `ASSET_DB_CONNECTION_STRING` to the same strong **local development** password.
3. Start Docker Desktop. Run the database seed script once:

   ```powershell
   .\scripts\seed_dev_db.ps1
   ```

   The script starts the SQL Server 2022 container, waits for it, creates `AssetManagement_AA_Test` from the supplied mock data, and creates the separate assistant-history tables. It will stop rather than overwrite an existing test database.
4. Install Python 3.10 or later and the ODBC Driver 18 for SQL Server. Then install the one Python dependency and start the app:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   py -m pip install -r requirements.txt
   py run.py
   ```

5. Open <http://127.0.0.1:8000>. Check <http://127.0.0.1:8000/api/v1/health>; expect `asset_database: ready`, `main_schema: ready`, and `history_schema: ready`.

If you already have a local SQL Server instance, run `database/01_create_mock_db.sql` and then `database/02_assistant_schema.sql` with SSMS or `sqlcmd`, and set `ASSET_DB_CONNECTION_STRING` in `.env` to that local test database. You can omit Docker in that case.

## Ollama (optional, recommended)

The deterministic question parser works without Ollama. Ollama improves interpretation of complex filters and follow-ups. Start the local Ollama service and make sure the configured model is available:

```powershell
ollama serve
ollama pull qwen2.5:1.5b
```

The default is `qwen2.5:1.5b`; change `OLLAMA_MODEL` in `.env` if you want another installed model. The model sees the question and a limited schema/query-plan description—not arbitrary SQL access. If Ollama is unavailable, deterministic supported questions still work; unsupported questions are clarified or declined.

## Suggested acceptance checks

Try these in the UI and compare the answer with direct SQL against the same local database:

- `How many assets do we have?` — expected 14 in this seed.
- `How many locations do we have?` — expected 3.
- `How many employees do we have?` — expected 6 active employees.
- `Show laptops by location` → `Make that a chart`.
- `How many assets?` → `How many are laptops?` → `What about Durban?`.
- `Show current assignments` — expected 2 active assignment rows, determined by `ReturnedAt IS NULL`.
- `Show warranty expiries` → `Only next quarter`.
- `Tell me about AST-2026-001` → `Show its history`.
- `Show transfers` and `Show recorded purchase costs`.
- Turn **Save this conversation** on, send a message, refresh the page, reopen it from the sidebar, then delete it. Turn saving off and verify later turns are not added to the saved transcript.

`tests/test_db_integration.py` runs the live SQL Server smoke checks when `ASSET_DB_CONNECTION_STRING` is configured. General unit tests are:

```powershell
py -m unittest discover -s tests -v
```

## API examples

`POST /api/v1/chat`:

```json
{
  "message": "How many laptops are assigned in Durban?",
  "conversation_id": null,
  "save_history": false
}
```

Response fields include `answer`, `intent`, validated `plan`, `rows`, `citations`, `evidence`, optional `chart`, and history status. Other routes:

- `GET /api/v1/health`
- `GET /api/v1/catalog`
- `GET /api/v1/conversations`
- `GET /api/v1/conversations/{conversation_id}`
- `DELETE /api/v1/conversations/{conversation_id}`

## Integration boundary and what remains for the main-app phase

The API is versioned and kept separate from the UI. For integration, the trusted main-app backend should call it or embed the UI behind the main app’s authentication. Replace the local `LOCAL_USER_ID` provider with the authenticated identity supplied by the main app; never trust an owner ID from a browser request. Configure least-privilege SQL credentials (read-only asset role plus narrowly scoped assistant-history permissions), secret storage, HTTPS/reverse proxy, approved CORS origins if cross-origin calls are needed, and the production retention/deletion policy. The actual main-app source/authentication code was not part of the uploaded files, so this package is integration-ready but is not yet integrated into that application.

## Known limitations of the supplied seed

This is a deliberately small test set, not a performance or production-accuracy dataset. Some source fields and relationships are inconsistent or incomplete. Current assignment queries use `dbo.AssetAssignments` with `ReturnedAt IS NULL`, rather than guessing from possibly stale asset columns. Transfer `TargetId` is shown as stored because the mock schema does not define a reliable target join for every transfer type. The app does not use asset document download URLs as knowledge sources.

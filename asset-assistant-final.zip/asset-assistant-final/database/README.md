# Local mock database

`01_create_mock_db.sql` is generated from the uploaded `AssetManagementWorking 1.sql` and keeps its mock records and schemas. It changes the database name to `AssetManagement_AA_Test`, removes the machine-specific MDF/LDF paths, sets compatibility level 160 for SQL Server 2022, and removes the SQL Server 2025-only `OPTIMIZED_LOCKING` setting. The assistant reads only the main-system-shaped `dbo` tables; the legacy `asset_management` and reporting schemas are retained in this isolated test DB but are not queried.

Run this once on a fresh SQL Server instance. It deliberately stops if `AssetManagement_AA_Test` already exists rather than dropping data. After it succeeds, run `02_assistant_schema.sql` in the same instance. Do not run this against production.

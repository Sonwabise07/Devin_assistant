USE [AssetManagement_AA_Test];
GO
IF SCHEMA_ID(N'assistant') IS NULL EXEC(N'CREATE SCHEMA [assistant]');
GO
IF OBJECT_ID(N'assistant.Conversations', N'U') IS NULL
BEGIN
    CREATE TABLE [assistant].[Conversations](
        [ConversationId] uniqueidentifier NOT NULL CONSTRAINT [PK_assistant_Conversations] PRIMARY KEY,
        [OwnerId] nvarchar(200) NOT NULL,
        [Title] nvarchar(200) NOT NULL,
        [SaveHistory] bit NOT NULL CONSTRAINT [DF_assistant_Conversations_SaveHistory] DEFAULT (1),
        [ContextJson] nvarchar(max) NULL,
        [CreatedAtUtc] datetime2(3) NOT NULL CONSTRAINT [DF_assistant_Conversations_CreatedAtUtc] DEFAULT (SYSUTCDATETIME()),
        [UpdatedAtUtc] datetime2(3) NOT NULL CONSTRAINT [DF_assistant_Conversations_UpdatedAtUtc] DEFAULT (SYSUTCDATETIME())
    );
    CREATE INDEX [IX_assistant_Conversations_Owner_Updated]
        ON [assistant].[Conversations]([OwnerId], [UpdatedAtUtc] DESC);
END;
GO
IF OBJECT_ID(N'assistant.Messages', N'U') IS NULL
BEGIN
    CREATE TABLE [assistant].[Messages](
        [MessageId] bigint IDENTITY(1,1) NOT NULL CONSTRAINT [PK_assistant_Messages] PRIMARY KEY,
        [ConversationId] uniqueidentifier NOT NULL,
        [Role] varchar(12) NOT NULL,
        [Content] nvarchar(max) NOT NULL,
        [MetadataJson] nvarchar(max) NULL,
        [CreatedAtUtc] datetime2(3) NOT NULL CONSTRAINT [DF_assistant_Messages_CreatedAtUtc] DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT [FK_assistant_Messages_Conversations] FOREIGN KEY ([ConversationId])
            REFERENCES [assistant].[Conversations]([ConversationId]) ON DELETE CASCADE,
        CONSTRAINT [CK_assistant_Messages_Role] CHECK ([Role] IN ('user','assistant'))
    );
    CREATE INDEX [IX_assistant_Messages_Conversation_Created]
        ON [assistant].[Messages]([ConversationId], [CreatedAtUtc], [MessageId]);
END;
GO

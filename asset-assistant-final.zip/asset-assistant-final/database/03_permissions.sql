USE [AssetManagement_AA_Test];
GO
-- Assign an existing database user to these roles. This script does not create logins/passwords.
IF DATABASE_PRINCIPAL_ID(N'aa_asset_reader') IS NULL CREATE ROLE [aa_asset_reader];
IF DATABASE_PRINCIPAL_ID(N'aa_history_writer') IS NULL CREATE ROLE [aa_history_writer];
GO
GRANT SELECT ON OBJECT::[dbo].[Assets] TO [aa_asset_reader];
GRANT SELECT ON OBJECT::[dbo].[AssetAssignments] TO [aa_asset_reader];
GRANT SELECT ON OBJECT::[dbo].[AssetHistory] TO [aa_asset_reader];
GRANT SELECT ON OBJECT::[dbo].[AssetTransfers] TO [aa_asset_reader];
GRANT SELECT ON OBJECT::[dbo].[Employees] TO [aa_asset_reader];
GRANT SELECT ON OBJECT::[dbo].[Departments] TO [aa_asset_reader];
GRANT SELECT ON OBJECT::[dbo].[Locations] TO [aa_asset_reader];
GRANT SELECT ON OBJECT::[dbo].[Storerooms] TO [aa_asset_reader];
GRANT SELECT, INSERT, UPDATE, DELETE ON OBJECT::[assistant].[Conversations] TO [aa_history_writer];
GRANT SELECT, INSERT, UPDATE, DELETE ON OBJECT::[assistant].[Messages] TO [aa_history_writer];
GO
-- Example after creating a database user: ALTER ROLE [aa_asset_reader] ADD MEMBER [your_app_user];
-- Example after creating a database user: ALTER ROLE [aa_history_writer] ADD MEMBER [your_app_user];

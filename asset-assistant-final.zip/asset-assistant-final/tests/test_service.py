import tempfile
import unittest
from pathlib import Path
from app.assistant import AssistantService
from app.config import Settings


class FakeDB:
    def __init__(self): self.calls=[]
    def query(self, sql, params=()):
        self.calls.append((sql,params))
        if "COUNT_BIG(DISTINCT a.AssetId)" in sql:
            return [{"Total": 5 if any("Laptop" in str(p) for p in params) else 14}]
        if "COUNT_BIG(1) AS Total FROM dbo.Locations" in sql:
            return [{"Total":3}]
        return []

class FakeHistory:
    def __init__(self): self.created=[]; self.appended=[]; self.flags=[]
    def ready(self): return True
    def create(self, **kw): self.created.append(kw)
    def append_turn(self, **kw): self.appended.append(kw)
    def set_saving(self,*args): self.flags.append(args)

class ServiceTests(unittest.TestCase):
    def service(self):
        tmp=tempfile.TemporaryDirectory()
        settings=Settings(asset_db="fake", history_db="fake", local_user_id="tester", knowledge_dir=Path(tmp.name), use_local_planner=False)
        service=AssistantService(settings)
        service.asset_db=FakeDB(); service.history_store=FakeHistory()
        return tmp,service

    def test_grounded_count_uses_mock_repository(self):
        tmp,s=self.service()
        try:
            result=s.chat({"message":"How many assets do we have?","save_history":False})
            self.assertIn("14 mock asset", result["answer"])
            self.assertTrue(result["evidence"])
        finally: tmp.cleanup()

    def test_followup_keeps_conversation_and_applies_type_filter(self):
        tmp,s=self.service()
        try:
            first=s.chat({"message":"How many assets?"})
            second=s.chat({"message":"How many are laptops?","conversation_id":first["conversation_id"]})
            self.assertEqual(second["plan"]["filters"]["asset_type"],"Laptop")
            self.assertEqual(s.asset_db.calls[-1][1],("%Laptop%",))
            self.assertIn("5 mock asset",second["answer"])
        finally: tmp.cleanup()

    def test_opt_in_history_persists_owner_scoped_conversation(self):
        tmp,s=self.service()
        try:
            result=s.chat({"message":"How many locations do we have?","save_history":True})
            self.assertTrue(result["history"]["saved"])
            self.assertEqual(len(s.history_store.created),1)
            self.assertEqual(s.history_store.created[0]["owner"],"tester")
        finally: tmp.cleanup()

    def test_turning_history_off_stops_persisting_future_turns(self):
        tmp,s=self.service()
        try:
            first=s.chat({"message":"How many assets?","save_history":True})
            saved_plan=first["plan"]
            second=s.chat({"message":"How many are laptops?","conversation_id":first["conversation_id"],"save_history":False})
            self.assertTrue(second["history"]["saved"])
            self.assertFalse(second["history"]["saving_enabled"])
            self.assertEqual(len(s.history_store.appended),0)
            self.assertEqual(s.history_store.flags[0][3],{"last_plan":saved_plan})
        finally: tmp.cleanup()

if __name__ == "__main__": unittest.main()

import unittest
from app.planner import deterministic_plan, make_plan


class PlannerTests(unittest.TestCase):
    def test_asset_count(self):
        plan = deterministic_plan("How many assets do we have?")
        self.assertEqual(plan["intent"], "asset_count")

    def test_count_by_asset_type(self):
        plan = deterministic_plan("How many laptops?")
        self.assertEqual(plan["intent"], "asset_count")
        self.assertEqual(plan["filters"]["asset_type"], "Laptop")

    def test_location_count(self):
        plan = deterministic_plan("How many locations do we have?")
        self.assertEqual(plan["intent"], "location_count")

    def test_assignment_count_is_not_mislabeled_as_asset_count(self):
        plan = deterministic_plan("How many current assignments do we have?")
        self.assertEqual(plan["intent"], "assignment_count")

    def test_cost_breakdown_uses_grouped_query(self):
        plan = deterministic_plan("Show recorded purchase cost by department")
        self.assertEqual(plan["intent"], "asset_breakdown")
        self.assertEqual(plan["group_by"], "department")
        self.assertEqual(plan["metric"], "cost")

    def test_breakdown_and_chart_followup(self):
        plan = deterministic_plan("Show laptops by location")
        self.assertEqual(plan["intent"], "asset_breakdown")
        self.assertEqual(plan["group_by"], "location")
        chart = deterministic_plan("Make that a chart", plan)
        self.assertTrue(chart["wants_chart"])

    def test_followup_filter_updates_existing_intent(self):
        plan = deterministic_plan("How many assets?")
        plan = deterministic_plan("How many are laptops?", plan)
        self.assertEqual(plan["intent"], "asset_count")
        self.assertEqual(plan["filters"]["asset_type"], "Laptop")
        plan = deterministic_plan("What about Durban?", plan)
        self.assertEqual(plan["filters"]["location"], "Durban")

    def test_history_followup_carries_asset_identifier(self):
        plan = deterministic_plan("Tell me about AST-2026-001")
        self.assertEqual(plan["intent"], "asset_detail")
        self.assertEqual(plan["filters"]["identifier"], "AST-2026-001")
        history = deterministic_plan("Show its history", plan)
        self.assertEqual(history["intent"], "history_search")
        self.assertEqual(history["filters"]["identifier"], "AST-2026-001")

    def test_unknown_question_does_not_generate_sql_plan(self):
        plan = make_plan("What is the capital of France?", None, use_local_model=False, ollama_url="", ollama_model="")
        self.assertEqual(plan["intent"], "unsupported")

    def test_unassigned_assets_are_not_routed_to_assignment_list(self):
        plan = deterministic_plan("Show unassigned assets")
        self.assertEqual(plan["intent"], "asset_search")
        self.assertIs(plan["filters"]["assigned"], False)

    def test_data_question_never_contains_sql(self):
        plan = deterministic_plan("How many laptops are assigned in Durban?")
        self.assertNotIn("sql", plan)
        self.assertEqual(plan["intent"], "asset_count")
        self.assertEqual(plan["filters"].get("assigned"), True)


if __name__ == "__main__":
    unittest.main()

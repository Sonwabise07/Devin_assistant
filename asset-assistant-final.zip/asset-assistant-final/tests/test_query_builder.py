import unittest
from app.query_builder import build_query


class QueryBuilderTests(unittest.TestCase):
    def test_asset_count_uses_distinct_and_allowlisted_tables(self):
        q = build_query({"intent":"asset_count","filters":{"asset_type":"Laptop"}})
        self.assertIn("COUNT_BIG(DISTINCT a.AssetId)", q.sql)
        self.assertIn("dbo.Assets", q.sql)
        self.assertIn("a.AssetType LIKE ?", q.sql)
        self.assertNotIn("Laptop", q.sql)
        self.assertEqual(q.params, ("%Laptop%",))

    def test_user_text_is_parameterized(self):
        hostile = "Laptop'; DROP TABLE dbo.Assets;--"
        q = build_query({"intent":"asset_search","filters":{"asset_type":hostile}})
        self.assertNotIn("DROP TABLE", q.sql)
        self.assertEqual(q.params, ("%Laptop'; DROP TABLE dbo.Assets;--%",))

    def test_current_assignments_are_defined_by_returned_at(self):
        q = build_query({"intent":"assignment_search","filters":{}})
        self.assertIn("aa.ReturnedAt IS NULL", q.sql)
        self.assertIn("dbo.AssetAssignments", q.sql)

    def test_assignment_count_uses_assignment_rows(self):
        q = build_query({"intent":"assignment_count","filters":{}})
        self.assertIn("COUNT_BIG(1)", q.sql)
        self.assertIn("dbo.AssetAssignments", q.sql)
        self.assertNotIn("dbo.Assets AS a OUTER APPLY", q.sql)

    def test_grouped_counts_use_distinct_asset_ids(self):
        q = build_query({"intent":"asset_breakdown","group_by":"location","filters":{"asset_type":"Laptop"}})
        self.assertIn("COUNT(DISTINCT a.AssetId)", q.sql)
        self.assertIn("GROUP BY", q.sql)
        self.assertEqual(q.params, ("%Laptop%",))

    def test_detail_requires_asset_identifier(self):
        with self.assertRaisesRegex(ValueError,"asset number"):
            build_query({"intent":"asset_detail","filters":{}})

    def test_unsupported_group_is_rejected(self):
        with self.assertRaisesRegex(ValueError,"supported breakdown"):
            build_query({"intent":"asset_breakdown","group_by":"password","filters":{}})


if __name__ == "__main__":
    unittest.main()

import os
import unittest
from app.db import SqlServer


CONN = os.environ.get("ASSET_DB_CONNECTION_STRING", "")
@unittest.skipUnless(CONN, "Set ASSET_DB_CONNECTION_STRING to run SQL Server integration tests")
class MockDatabaseIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.db=SqlServer(CONN)
    def test_main_mock_counts(self):
        expected={
            "Assets": ("SELECT COUNT_BIG(1) AS Total FROM dbo.Assets",14),
            "Locations": ("SELECT COUNT_BIG(1) AS Total FROM dbo.Locations",3),
            "Employees": ("SELECT COUNT_BIG(1) AS Total FROM dbo.Employees WHERE IsActive=1",6),
            "CurrentAssignments": ("SELECT COUNT_BIG(1) AS Total FROM dbo.AssetAssignments WHERE ReturnedAt IS NULL",2),
            "History": ("SELECT COUNT_BIG(1) AS Total FROM dbo.AssetHistory",7),
            "Transfers": ("SELECT COUNT_BIG(1) AS Total FROM dbo.AssetTransfers",1),
        }
        for name,(sql,expected_count) in expected.items():
            with self.subTest(table=name):
                self.assertEqual(int(self.db.query(sql)[0]["Total"]),expected_count)
    def test_read_only_query_templates_execute(self):
        rows=self.db.query("SELECT TOP (3) AssetNo, AssetType FROM dbo.Assets ORDER BY AssetNo")
        self.assertTrue(rows)
        self.assertLessEqual(len(rows),3)

if __name__ == "__main__": unittest.main()

from __future__ import annotations

import json
from typing import Any

from app.db import SqlServer


class HistoryUnavailable(RuntimeError):
    pass


class HistoryStore:
    """SQL Server conversation history in a separate assistant-owned schema."""

    def __init__(self, db: SqlServer):
        self.db = db

    def ready(self) -> bool:
        try:
            rows = self.db.query("SELECT CASE WHEN OBJECT_ID(N'assistant.Conversations', N'U') IS NOT NULL AND OBJECT_ID(N'assistant.Messages', N'U') IS NOT NULL THEN 1 ELSE 0 END AS Ready")
            return bool(rows and rows[0].get("Ready"))
        except Exception:
            return False

    def list_for_owner(self, owner: str, limit: int = 50) -> list[dict[str, Any]]:
        sql = "SELECT TOP (?) ConversationId, Title, SaveHistory, CreatedAtUtc, UpdatedAtUtc FROM assistant.Conversations WHERE OwnerId = ? ORDER BY UpdatedAtUtc DESC"
        return self.db.query(sql, (max(1, min(100, limit)), owner))

    def load(self, owner: str, conversation_id: str) -> dict[str, Any] | None:
        with self.db.connection(autocommit=True) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute("SELECT ConversationId, Title, SaveHistory, ContextJson, CreatedAtUtc, UpdatedAtUtc FROM assistant.Conversations WHERE OwnerId = ? AND ConversationId = ?", owner, conversation_id)
                row = cursor.fetchone()
                if row is None:
                    return None
                names = [d[0] for d in cursor.description]
                conversation = dict(zip(names, row))
                cursor.execute("SELECT Role, Content, MetadataJson, CreatedAtUtc FROM assistant.Messages WHERE ConversationId = ? ORDER BY CreatedAtUtc, MessageId", conversation_id)
                message_names = [d[0] for d in cursor.description]
                messages = [dict(zip(message_names, r)) for r in cursor.fetchall()]
            finally:
                cursor.close()
        context = {}
        if conversation.get("ContextJson"):
            try:
                context = json.loads(conversation["ContextJson"])
            except (TypeError, json.JSONDecodeError):
                context = {}
        parsed_messages = []
        for item in messages:
            metadata = {}
            try:
                metadata = json.loads(item.get("MetadataJson") or "{}")
            except (TypeError, json.JSONDecodeError):
                pass
            parsed_messages.append({
                "role": item["Role"], "content": item["Content"],
                "metadata": metadata, "created_at": item["CreatedAtUtc"].isoformat() if item.get("CreatedAtUtc") else None,
            })
        return {
            "conversation_id": str(conversation["ConversationId"]),
            "title": conversation["Title"], "save_history": bool(conversation["SaveHistory"]),
            "created_at": conversation["CreatedAtUtc"].isoformat() if conversation.get("CreatedAtUtc") else None,
            "updated_at": conversation["UpdatedAtUtc"].isoformat() if conversation.get("UpdatedAtUtc") else None,
            "context": context, "messages": parsed_messages,
        }

    @staticmethod
    def _insert_messages(cursor: Any, conversation_id: str, messages: list[dict[str, Any]]) -> None:
        for message in messages:
            meta = message.get("metadata") or {}
            cursor.execute(
                "INSERT INTO assistant.Messages (ConversationId, Role, Content, MetadataJson) VALUES (?, ?, ?, ?)",
                conversation_id, message["role"], message["content"], json.dumps(meta, ensure_ascii=False),
            )

    def create(self, *, owner: str, conversation_id: str, title: str, context: dict, messages: list[dict]) -> None:
        with self.db.connection(autocommit=False) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(
                    "INSERT INTO assistant.Conversations (ConversationId, OwnerId, Title, SaveHistory, ContextJson) VALUES (?, ?, ?, 1, ?)",
                    conversation_id, owner, title[:200], json.dumps(context, ensure_ascii=False),
                )
                self._insert_messages(cursor, conversation_id, messages)
                connection.commit()
            except Exception as exc:
                connection.rollback()
                raise HistoryUnavailable("Conversation could not be saved. Verify the assistant schema and history permissions.") from exc
            finally:
                cursor.close()

    def append_turn(self, *, owner: str, conversation_id: str, context: dict, messages: list[dict]) -> None:
        with self.db.connection(autocommit=False) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(
                    "UPDATE assistant.Conversations SET ContextJson = ?, UpdatedAtUtc = SYSUTCDATETIME(), SaveHistory = 1 WHERE OwnerId = ? AND ConversationId = ?",
                    json.dumps(context, ensure_ascii=False), owner, conversation_id,
                )
                if cursor.rowcount != 1:
                    raise HistoryUnavailable("Saved conversation was not found for this local user.")
                self._insert_messages(cursor, conversation_id, messages)
                connection.commit()
            except Exception as exc:
                connection.rollback()
                if isinstance(exc, HistoryUnavailable):
                    raise
                raise HistoryUnavailable("Conversation could not be updated. Verify the assistant schema and history permissions.") from exc
            finally:
                cursor.close()

    def set_saving(self, owner: str, conversation_id: str, enabled: bool, context: dict) -> None:
        with self.db.connection(autocommit=True) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(
                    "UPDATE assistant.Conversations SET SaveHistory = ?, ContextJson = ?, UpdatedAtUtc = SYSUTCDATETIME() WHERE OwnerId = ? AND ConversationId = ?",
                    int(enabled), json.dumps(context, ensure_ascii=False), owner, conversation_id,
                )
                if cursor.rowcount != 1:
                    raise HistoryUnavailable("Saved conversation was not found for this local user.")
            finally:
                cursor.close()

    def delete(self, owner: str, conversation_id: str) -> bool:
        with self.db.connection(autocommit=True) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute("DELETE FROM assistant.Conversations WHERE OwnerId = ? AND ConversationId = ?", owner, conversation_id)
                return cursor.rowcount == 1
            finally:
                cursor.close()

from __future__ import annotations

from contextlib import contextmanager
from decimal import Decimal
from datetime import date, datetime
from typing import Any, Iterator
import uuid


class DatabaseUnavailable(RuntimeError):
    pass


def json_value(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, bytes):
        return value.hex()
    return value


class SqlServer:
    """Thin SQL Server adapter. Callers supply only application-owned SQL templates."""

    def __init__(self, connection_string: str):
        self.connection_string = connection_string.strip()

    def _pyodbc(self):
        if not self.connection_string:
            raise DatabaseUnavailable("SQL Server connection is not configured. See .env.example and README.md.")
        try:
            import pyodbc  # type: ignore
        except ImportError as exc:
            raise DatabaseUnavailable("pyodbc is missing. Install dependencies with: python -m pip install -r requirements.txt") from exc
        return pyodbc

    @contextmanager
    def connection(self, *, autocommit: bool = True) -> Iterator[Any]:
        pyodbc = self._pyodbc()
        try:
            connection = pyodbc.connect(self.connection_string, timeout=7, autocommit=autocommit)
        except Exception as exc:
            raise DatabaseUnavailable("Could not connect to the configured SQL Server. Check that the local database is running and .env is correct.") from exc
        try:
            yield connection
        finally:
            connection.close()

    def query(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        with self.connection(autocommit=True) as connection:
            cursor = connection.cursor()
            try:
                cursor.timeout = 15
                cursor.execute(sql, *params)
                names = [col[0] for col in cursor.description] if cursor.description else []
                return [{name: json_value(value) for name, value in zip(names, row)} for row in cursor.fetchall()]
            finally:
                cursor.close()

    def ping(self) -> dict[str, Any]:
        rows = self.query("SELECT DB_NAME() AS DatabaseName, CAST(1 AS int) AS Ready")
        return rows[0] if rows else {"Ready": 0}


def clean_connection_string(value: str) -> str:
    """Redact credentials before a string is ever emitted to logs/errors."""
    if not value:
        return "(not configured)"
    parts = []
    for part in value.split(";"):
        if "=" in part:
            key, val = part.split("=", 1)
            if key.strip().lower() in {"pwd", "password"}:
                val = "***"
            parts.append(f"{key}={val}")
        elif part:
            parts.append(part)
    return ";".join(parts)

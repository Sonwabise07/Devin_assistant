from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path = ROOT / ".env") -> None:
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        os.environ.setdefault(key, value)


_load_dotenv()


def _bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    host: str = os.environ.get("HOST", "127.0.0.1")
    port: int = int(os.environ.get("PORT", "8000"))
    asset_db: str = os.environ.get("ASSET_DB_CONNECTION_STRING", "")
    history_db: str = os.environ.get("HISTORY_DB_CONNECTION_STRING", "")
    local_user_id: str = os.environ.get("LOCAL_USER_ID", "local-tester")
    ollama_url: str = os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
    ollama_model: str = os.environ.get("OLLAMA_MODEL", "qwen2.5:1.5b")
    knowledge_dir: Path = Path(os.environ.get("KNOWLEDGE_DIR", str(ROOT / "knowledge")))
    save_history_default: bool = _bool("SAVE_HISTORY_DEFAULT", False)
    use_local_planner: bool = _bool("USE_LOCAL_PLANNER", True)
    cors_origins: tuple[str, ...] = tuple(
        item.strip() for item in os.environ.get("CORS_ALLOWED_ORIGINS", "").split(",") if item.strip()
    )

    @property
    def history_connection(self) -> str:
        return self.history_db or self.asset_db


settings = Settings()

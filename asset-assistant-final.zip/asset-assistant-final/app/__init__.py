"""Asset Assistant v1 — standalone, integration-oriented test service."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Query:
    sql: str
    params: tuple[Any, ...]
    sources: tuple[str, ...]
    label: str


ASSET_FROM = """
FROM dbo.Assets AS a
OUTER APPLY (
    SELECT TOP (1) aa.EmployeeId, aa.EmployeeName, aa.LocationId, aa.AssignedAt
    FROM dbo.AssetAssignments AS aa
    WHERE aa.AssetId = a.AssetId AND aa.ReturnedAt IS NULL
    ORDER BY aa.AssignedAt DESC, aa.AssignmentId DESC
) AS cur
LEFT JOIN dbo.Employees AS e ON e.EmployeeId = COALESCE(cur.EmployeeId, a.EmployeeId)
LEFT JOIN dbo.Locations AS la ON la.LocationId = a.LocationId
LEFT JOIN dbo.Locations AS lc ON lc.LocationId = cur.LocationId
LEFT JOIN dbo.Departments AS da ON da.DepartmentId = a.DepartmentId
LEFT JOIN dbo.Departments AS de ON de.DepartmentId = e.DepartmentId
""".strip()

GROUPS = {
    "location": "COALESCE(la.Name, lc.Name, a.LocationId, cur.LocationId, 'Unassigned')",
    "region": "COALESCE(a.Region, la.Region, lc.Region, 'Unspecified')",
    "department": "COALESCE(da.Name, de.Name, a.DepartmentId, e.DepartmentId, 'Unassigned')",
    "employee": "COALESCE(cur.EmployeeName, e.FullName, a.EmployeeName, 'Unassigned')",
    "asset_type": "a.AssetType",
    "operational_status": "a.OperationalStatus",
    "lifecycle_state": "a.LifecycleState",
}
MAX_ROWS = 50


def _limit(plan: dict) -> int:
    try:
        return max(1, min(MAX_ROWS, int(plan.get("limit", 20))))
    except (ValueError, TypeError):
        return 20


def _like(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_").replace("[", "\\[")
    return "%" + escaped + "%"


def _asset_where(filters: dict[str, Any]) -> tuple[list[str], list[Any]]:
    clauses: list[str] = []
    params: list[Any] = []
    text_fields = {
        "asset_type": "a.AssetType",
        "lifecycle_state": "a.LifecycleState",
        "operational_status": "a.OperationalStatus",
        "asset_no": "a.AssetNo",
        "asset_tag": "a.AssetTag",
        "serial_number": "a.SerialNumber",
    }
    for key, column in text_fields.items():
        value = filters.get(key)
        if isinstance(value, str) and value.strip():
            clauses.append(f"{column} LIKE ? ESCAPE N'\\'")
            params.append(_like(value.strip()))

    identifier = filters.get("identifier")
    if isinstance(identifier, str) and identifier.strip():
        clauses.append("(a.AssetNo = ? OR a.AssetTag = ? OR a.SerialNumber = ? OR a.AssetId = ?)")
        params.extend([identifier.strip()] * 4)

    location = filters.get("location")
    if isinstance(location, str) and location.strip():
        clauses.append("(la.Name LIKE ? ESCAPE N'\\' OR lc.Name LIKE ? ESCAPE N'\\' OR a.LocationId LIKE ? ESCAPE N'\\' OR cur.LocationId LIKE ? ESCAPE N'\\')")
        params.extend([_like(location.strip())] * 4)

    region = filters.get("region")
    if isinstance(region, str) and region.strip():
        clauses.append("(COALESCE(a.Region, la.Region, lc.Region, '') LIKE ? ESCAPE N'\\')")
        params.append(_like(region.strip()))

    department = filters.get("department")
    if isinstance(department, str) and department.strip():
        clauses.append("(da.Name LIKE ? ESCAPE N'\\' OR de.Name LIKE ? ESCAPE N'\\' OR a.DepartmentId LIKE ? ESCAPE N'\\' OR e.DepartmentId LIKE ? ESCAPE N'\\')")
        params.extend([_like(department.strip())] * 4)

    employee = filters.get("employee")
    if isinstance(employee, str) and employee.strip():
        clauses.append("(cur.EmployeeName LIKE ? ESCAPE N'\\' OR e.FullName LIKE ? ESCAPE N'\\' OR a.EmployeeName LIKE ? ESCAPE N'\\' OR cur.EmployeeId LIKE ? ESCAPE N'\\' OR a.EmployeeId LIKE ? ESCAPE N'\\')")
        params.extend([_like(employee.strip())] * 5)

    assigned = filters.get("assigned")
    if isinstance(assigned, bool):
        exists_sql = "EXISTS (SELECT 1 FROM dbo.AssetAssignments AS ax WHERE ax.AssetId = a.AssetId AND ax.ReturnedAt IS NULL)"
        clauses.append(exists_sql if assigned else f"NOT {exists_sql}")

    for key, column, op in (
        ("warranty_from", "a.WarrantyEnd", ">="),
        ("warranty_to", "a.WarrantyEnd", "<"),
        ("acquisition_from", "a.AcquisitionDate", ">="),
        ("acquisition_to", "a.AcquisitionDate", "<"),
    ):
        value = filters.get(key)
        if isinstance(value, str) and value:
            clauses.append(f"{column} {op} ?")
            params.append(value)
    return clauses, params


def _where_sql(clauses: list[str]) -> str:
    return " WHERE " + " AND ".join(clauses) if clauses else ""


def build_query(plan: dict) -> Query:
    intent = plan.get("intent")
    filters = plan.get("filters") if isinstance(plan.get("filters"), dict) else {}
    limit = _limit(plan)
    where, params = _asset_where(filters)
    where_sql = _where_sql(where)

    if intent == "location_count":
        extra = []
        p: list[Any] = []
        region = filters.get("region")
        if isinstance(region, str) and region.strip():
            extra.append("(Region LIKE ? ESCAPE N'\\' OR Name LIKE ? ESCAPE N'\\')")
            p.extend([_like(region.strip())] * 2)
        return Query("SELECT COUNT_BIG(1) AS Total FROM dbo.Locations" + _where_sql(extra), tuple(p), ("dbo.Locations",), "location_count")

    if intent == "employee_count":
        extra = []
        p: list[Any] = []
        department = filters.get("department")
        if isinstance(department, str) and department.strip():
            extra.append("(d.Name LIKE ? ESCAPE N'\\' OR d.DepartmentId LIKE ? ESCAPE N'\\')")
            p.extend([_like(department.strip())] * 2)
        active = "e.IsActive = 1"
        return Query("SELECT COUNT_BIG(1) AS Total FROM dbo.Employees AS e LEFT JOIN dbo.Departments AS d ON d.DepartmentId = e.DepartmentId WHERE " + active + (" AND " + " AND ".join(extra) if extra else ""), tuple(p), ("dbo.Employees", "dbo.Departments"), "active_employee_count")

    if intent in {"asset_count", "asset_breakdown", "asset_search", "asset_detail", "warranty_search", "cost_summary", "acquisition_trend"}:
        if intent == "asset_detail" and not filters.get("identifier") and not any(filters.get(k) for k in ("asset_no", "asset_tag", "serial_number")):
            raise ValueError("Tell me an asset number, tag, or serial number so I know which asset to look up.")
        if intent == "asset_count":
            sql = "SELECT COUNT_BIG(DISTINCT a.AssetId) AS Total " + ASSET_FROM + where_sql
            return Query(sql, tuple(params), ("dbo.Assets", "dbo.AssetAssignments", "dbo.Locations", "dbo.Departments", "dbo.Employees"), "asset_count")
        if intent == "asset_breakdown":
            dimension = plan.get("group_by")
            expression = GROUPS.get(dimension)
            if not expression:
                raise ValueError("Choose a supported breakdown: location, region, department, employee, asset type, operational status, or lifecycle state.")
            metric = plan.get("metric", "count")
            value_expr = "SUM(COALESCE(a.PurchaseCost, 0))" if metric == "cost" else "COUNT(DISTINCT a.AssetId)"
            alias = "RecordedPurchaseCost" if metric == "cost" else "AssetCount"
            sql = f"SELECT TOP ({limit}) {expression} AS Category, {value_expr} AS {alias} {ASSET_FROM}{where_sql} GROUP BY {expression} ORDER BY {alias} DESC, Category ASC"
            return Query(sql, tuple(params), ("dbo.Assets", "dbo.Locations", "dbo.Departments", "dbo.Employees", "dbo.AssetAssignments"), "asset_breakdown")
        if intent == "acquisition_trend":
            metric = plan.get("metric", "count")
            value_expr = "SUM(COALESCE(a.PurchaseCost, 0))" if metric == "cost" else "COUNT(DISTINCT a.AssetId)"
            alias = "RecordedPurchaseCost" if metric == "cost" else "AssetCount"
            month = "CONVERT(char(7), a.AcquisitionDate, 120)"
            clauses = list(where)
            clauses.append("a.AcquisitionDate IS NOT NULL")
            sql = f"SELECT TOP ({limit}) {month} AS Category, {value_expr} AS {alias} {ASSET_FROM}{_where_sql(clauses)} GROUP BY {month} ORDER BY Category ASC"
            return Query(sql, tuple(params), ("dbo.Assets",), "acquisition_trend")
        if intent == "cost_summary":
            sql = "SELECT SUM(a.PurchaseCost) AS RecordedPurchaseCost, COUNT_BIG(a.PurchaseCost) AS AssetsWithRecordedCost, COUNT_BIG(1) AS AssetsInScope " + ASSET_FROM + where_sql
            return Query(sql, tuple(params), ("dbo.Assets", "dbo.Locations", "dbo.Departments", "dbo.Employees", "dbo.AssetAssignments"), "recorded_purchase_cost")
        if intent == "warranty_search":
            clauses = list(where) + ["a.WarrantyEnd IS NOT NULL"]
            sql = f"SELECT TOP ({limit}) a.AssetNo, a.AssetTag, a.AssetType, a.Make, a.Model, a.WarrantyStart, a.WarrantyEnd, COALESCE(la.Name, lc.Name, a.LocationId, cur.LocationId) AS Location, COALESCE(cur.EmployeeName, e.FullName, a.EmployeeName) AS AssignedTo {ASSET_FROM}{_where_sql(clauses)} ORDER BY a.WarrantyEnd ASC, a.AssetNo ASC"
            return Query(sql, tuple(params), ("dbo.Assets", "dbo.Locations", "dbo.Employees", "dbo.AssetAssignments"), "warranty_search")
        selected = "a.AssetNo, a.AssetTag, a.SerialNumber, a.AssetType, a.Make, a.Model, a.LifecycleState, a.OperationalStatus, COALESCE(cur.EmployeeName, e.FullName, a.EmployeeName) AS AssignedTo, COALESCE(la.Name, lc.Name, a.LocationId, cur.LocationId) AS Location, COALESCE(da.Name, de.Name, a.DepartmentId, e.DepartmentId) AS Department, a.WarrantyEnd, a.PurchaseCost"
        sql = f"SELECT TOP ({limit}) {selected} {ASSET_FROM}{where_sql} ORDER BY a.AssetNo ASC"
        return Query(sql, tuple(params), ("dbo.Assets", "dbo.AssetAssignments", "dbo.Employees", "dbo.Locations", "dbo.Departments"), "asset_lookup")

    if intent in {"assignment_search", "assignment_count"}:
        clauses = ["aa.ReturnedAt IS NULL"]
        p: list[Any] = []
        employee = filters.get("employee")
        if isinstance(employee, str) and employee.strip():
            clauses.append("(aa.EmployeeName LIKE ? ESCAPE N'\\' OR aa.EmployeeId LIKE ? ESCAPE N'\\' OR e.FullName LIKE ? ESCAPE N'\\')")
            p.extend([_like(employee.strip())] * 3)
        location = filters.get("location")
        if isinstance(location, str) and location.strip():
            clauses.append("(l.Name LIKE ? ESCAPE N'\\' OR aa.LocationId LIKE ? ESCAPE N'\\')")
            p.extend([_like(location.strip())] * 2)
        department = filters.get("department")
        if isinstance(department, str) and department.strip():
            clauses.append("(d.Name LIKE ? ESCAPE N'\\' OR d.DepartmentId LIKE ? ESCAPE N'\\')")
            p.extend([_like(department.strip())] * 2)
        asset_type = filters.get("asset_type")
        if isinstance(asset_type, str) and asset_type.strip():
            clauses.append("a.AssetType LIKE ? ESCAPE N'\\'")
            p.append(_like(asset_type.strip()))
        identifier = filters.get("identifier")
        if isinstance(identifier, str) and identifier.strip():
            clauses.append("(a.AssetNo = ? OR a.AssetTag = ? OR a.SerialNumber = ? OR a.AssetId = ?)")
            p.extend([identifier.strip()] * 4)
        source = "FROM dbo.AssetAssignments AS aa JOIN dbo.Assets AS a ON a.AssetId = aa.AssetId LEFT JOIN dbo.Employees AS e ON e.EmployeeId = aa.EmployeeId LEFT JOIN dbo.Locations AS l ON l.LocationId = aa.LocationId LEFT JOIN dbo.Departments AS d ON d.DepartmentId = e.DepartmentId"
        if intent == "assignment_count":
            sql = f"SELECT COUNT_BIG(1) AS Total {source} WHERE {' AND '.join(clauses)}"
            return Query(sql, tuple(p), ("dbo.AssetAssignments", "dbo.Assets", "dbo.Employees", "dbo.Locations", "dbo.Departments"), "current_assignment_count")
        sql = f"SELECT TOP ({limit}) a.AssetNo, a.AssetTag, a.AssetType, aa.EmployeeName, aa.EmployeeId, aa.AssignedAt, COALESCE(l.Name, aa.LocationId) AS Location, d.Name AS Department {source} WHERE {' AND '.join(clauses)} ORDER BY aa.AssignedAt DESC, a.AssetNo ASC"
        return Query(sql, tuple(p), ("dbo.AssetAssignments", "dbo.Assets", "dbo.Employees", "dbo.Locations", "dbo.Departments"), "current_assignments")

    if intent == "history_search":
        clauses = []
        if filters.get("identifier"):
            identifier = str(filters["identifier"])
            clauses.append("(a.AssetNo = ? OR a.AssetTag = ? OR a.SerialNumber = ? OR a.AssetId = ?)")
            p: list[Any] = [identifier] * 4
        else:
            p = []
        action = filters.get("action")
        if isinstance(action, str) and action.strip():
            clauses.append("h.Action LIKE ? ESCAPE N'\\'")
            p.append(_like(action.strip()))
        sql = f"SELECT TOP ({limit}) a.AssetNo, a.AssetType, h.Action, h.Summary, h.ChangedBy, h.ChangedAt FROM dbo.AssetHistory AS h JOIN dbo.Assets AS a ON a.AssetId = h.AssetId{_where_sql(clauses)} ORDER BY h.ChangedAt DESC"
        return Query(sql, tuple(p), ("dbo.AssetHistory", "dbo.Assets"), "asset_history")

    if intent == "transfer_search":
        clauses = []
        p: list[Any] = []
        for key, column in (("transfer_status", "t.Status"), ("transfer_type", "t.TransferType")):
            value = filters.get(key)
            if isinstance(value, str) and value.strip():
                clauses.append(f"{column} LIKE ? ESCAPE N'\\'")
                p.append(_like(value.strip()))
        if filters.get("identifier"):
            identifier = str(filters["identifier"])
            clauses.append("(a.AssetNo = ? OR a.AssetTag = ? OR a.SerialNumber = ? OR a.AssetId = ?)")
            p.extend([identifier] * 4)
        sql = f"SELECT TOP ({limit}) a.AssetNo, a.AssetType, t.TransferType, t.TargetId, t.Status, t.RequestedBy, t.RequestedAt, t.CompletedAt, t.Notes FROM dbo.AssetTransfers AS t JOIN dbo.Assets AS a ON a.AssetId = t.AssetId{_where_sql(clauses)} ORDER BY t.RequestedAt DESC"
        return Query(sql, tuple(p), ("dbo.AssetTransfers", "dbo.Assets"), "asset_transfers")

    raise ValueError("I couldn't map that request to an approved database query. Try asset counts, asset lookup, current assignments, warranty dates, history, transfers, costs, or a breakdown by location/type/department/status.")

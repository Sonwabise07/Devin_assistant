from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
import json
import re

from app.assistant import AssistantService
from app.config import ROOT, settings
from app.db import DatabaseUnavailable

WEB = ROOT / "web"
SERVICE = AssistantService(settings)
MAX_BODY = 1_000_000


def _json_default(value):
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


class Handler(BaseHTTPRequestHandler):
    server_version = "AssetAssistant/1.0"

    def log_message(self, fmt, *args):
        # Do not log messages, prompts, SQL parameters, or connection strings.
        print(f"{self.client_address[0]} - {fmt % args}")

    def _cors(self):
        origin = self.headers.get("Origin")
        if origin and origin in settings.cors_origins:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")

    def _send_json(self, status: int, payload: dict):
        body = json.dumps(payload, ensure_ascii=False, default=_json_default).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _send_static(self, name: str, content_type: str):
        path = (WEB / name).resolve()
        if WEB.resolve() not in path.parents:
            self._send_json(404, {"error": "Not found"})
            return
        try:
            body = path.read_bytes()
        except OSError:
            self._send_json(404, {"error": "Not found"})
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            return self._send_static("index.html", "text/html; charset=utf-8")
        static = {"/app.js": ("app.js", "text/javascript; charset=utf-8"), "/styles.css": ("styles.css", "text/css; charset=utf-8")}
        if path in static:
            return self._send_static(*static[path])
        if path == "/api/v1/health":
            return self._send_json(200, SERVICE.health())
        if path == "/api/v1/catalog":
            return self._send_json(200, SERVICE.catalog())
        if path == "/api/v1/conversations":
            try:
                return self._send_json(200, {"conversations": SERVICE.list_conversations()})
            except DatabaseUnavailable as exc:
                return self._send_json(503, {"error": str(exc)})
        match = re.fullmatch(r"/api/v1/conversations/([0-9a-fA-F-]{36})", path)
        if match:
            try:
                conversation = SERVICE.get_conversation(match.group(1))
                if not conversation:
                    return self._send_json(404, {"error": "Conversation not found."})
                return self._send_json(200, conversation)
            except DatabaseUnavailable as exc:
                return self._send_json(503, {"error": str(exc)})
        return self._send_json(404, {"error": "Not found"})

    def do_DELETE(self):
        path = urlparse(self.path).path
        match = re.fullmatch(r"/api/v1/conversations/([0-9a-fA-F-]{36})", path)
        if not match:
            return self._send_json(404, {"error": "Not found"})
        try:
            if SERVICE.delete_conversation(match.group(1)):
                return self._send_json(200, {"deleted": True})
            return self._send_json(404, {"error": "Conversation not found."})
        except DatabaseUnavailable as exc:
            return self._send_json(503, {"error": str(exc)})

    def do_POST(self):
        if urlparse(self.path).path != "/api/v1/chat":
            return self._send_json(404, {"error": "Not found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_BODY:
                return self._send_json(413, {"error": "Request body must be between 1 byte and 1 MB."})
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                return self._send_json(400, {"error": "Request body must be a JSON object."})
            result = SERVICE.chat(payload)
            return self._send_json(200, result)
        except (UnicodeDecodeError, json.JSONDecodeError):
            return self._send_json(400, {"error": "Request body must be valid UTF-8 JSON."})
        except ValueError as exc:
            return self._send_json(400, {"error": str(exc)})
        except DatabaseUnavailable as exc:
            return self._send_json(503, {"error": str(exc)})
        except Exception:
            return self._send_json(500, {"error": "Unexpected server error. Check the application console; message content is not logged."})


def main():
    server = ThreadingHTTPServer((settings.host, settings.port), Handler)
    print(f"Asset Assistant v1: http://{settings.host}:{settings.port}")
    print("API: /api/v1/health | /api/v1/catalog | /api/v1/chat | /api/v1/conversations")
    print("Local mock mode only. Structured answers require SQL Server; history requires assistant schema.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Asset Assistant.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()

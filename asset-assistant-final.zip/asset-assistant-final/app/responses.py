from __future__ import annotations

from typing import Any


def _n(value: Any) -> int:
    try:
        return int(value or 0)
    except (ValueError, TypeError):
        return 0


def summarize(plan: dict, rows: list[dict]) -> str:
    intent = plan.get("intent")
    filters = plan.get("filters", {})
    if intent == "asset_count":
        count = _n(rows[0].get("Total")) if rows else 0
        return f"There are {count} mock asset record(s) matching that request."
    if intent == "location_count":
        count = _n(rows[0].get("Total")) if rows else 0
        return f"The mock database contains {count} location record(s)."
    if intent == "employee_count":
        count = _n(rows[0].get("Total")) if rows else 0
        return f"The mock database contains {count} active employee record(s)."
    if intent == "assignment_count":
        count = _n(rows[0].get("Total")) if rows else 0
        return f"The mock database contains {count} current assignment record(s)."
    if intent == "asset_breakdown":
        metric = "recorded purchase cost" if plan.get("metric") == "cost" else "asset record(s)"
        return f"Here is the breakdown by {plan.get('group_by', 'category')} for {len(rows)} group(s), showing {metric}."
    if intent == "acquisition_trend":
        metric = "recorded purchase cost" if plan.get("metric") == "cost" else "asset acquisition record(s)"
        return f"Here is the monthly trend for {len(rows)} month(s), showing {metric}."
    if intent == "cost_summary":
        row = rows[0] if rows else {}
        total = row.get("RecordedPurchaseCost")
        known = _n(row.get("AssetsWithRecordedCost"))
        count = _n(row.get("AssetsInScope"))
        if total is None:
            return f"No purchase-cost values are recorded for the {count} asset record(s) in scope."
        return f"Recorded purchase cost totals {total:,.2f} across {known} asset record(s) with a cost recorded (of {count} in scope). This is recorded purchase cost, not an independently verified current valuation."
    labels = {
        "asset_detail": "asset detail record(s)", "asset_search": "matching asset record(s)",
        "warranty_search": "asset record(s) with a recorded warranty end date",
        "assignment_search": "current assignment record(s)", "history_search": "history event(s)",
        "transfer_search": "transfer record(s)",
    }
    phrase = labels.get(intent, "matching record(s)")
    if not rows:
        return f"No matching {phrase} were found in the mock database."
    return f"Found {len(rows)} {phrase} in the mock database."


def chart_for(plan: dict, rows: list[dict]) -> dict | None:
    if not plan.get("wants_chart") or not rows:
        return None
    value_key = "RecordedPurchaseCost" if plan.get("metric") == "cost" else "AssetCount"
    if not all("Category" in row and value_key in row for row in rows):
        return None
    return {
        "type": "bar", "title": f"{plan.get('group_by') or 'Monthly'} breakdown",
        "labels": [str(r.get("Category") or "Unspecified") for r in rows],
        "values": [float(r.get(value_key) or 0) for r in rows],
        "value_label": "Recorded purchase cost" if plan.get("metric") == "cost" else "Asset records",
    }

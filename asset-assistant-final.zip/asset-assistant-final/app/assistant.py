from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import threading
import uuid
from typing import Any

from app.config import Settings
from app.db import DatabaseUnavailable, SqlServer
from app.history import HistoryStore, HistoryUnavailable
from app.knowledge import retrieve, grounded_answer
from app.planner import make_plan
from app.query_builder import build_query
from app.responses import summarize, chart_for


class AssistantService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.asset_db = SqlServer(settings.asset_db)
        self.history_store = HistoryStore(SqlServer(settings.history_connection))
        self._memory: dict[str, dict[str, Any]] = {}
        self._lock = threading.RLock()

    def health(self) -> dict:
        data = {"status": "ok", "api_version": "v1", "environment": "local_mock_test", "asset_database": "not_configured", "history_schema": "not_configured", "knowledge_documents": 0}
        if self.settings.knowledge_dir.is_dir():
            data["knowledge_documents"] = len(list(self.settings.knowledge_dir.glob("*.md")))
        try:
            ping = self.asset_db.ping()
            data["asset_database"] = "ready"
            data["database_name"] = ping.get("DatabaseName")
            # Verify the expected main-system-shaped tables before declaring readiness.
            table_check = self.asset_db.query("SELECT CASE WHEN OBJECT_ID(N'dbo.Assets',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.AssetAssignments',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.AssetHistory',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.AssetTransfers',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.Employees',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.Departments',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.Locations',N'U') IS NOT NULL AND OBJECT_ID(N'dbo.Storerooms',N'U') IS NOT NULL THEN 1 ELSE 0 END AS Ready")
            data["main_schema"] = "ready" if table_check and table_check[0].get("Ready") else "missing_tables"
        except DatabaseUnavailable as exc:
            data["asset_database"] = "unavailable"
            data["database_message"] = str(exc)
        except Exception:
            data["asset_database"] = "unavailable"
            data["database_message"] = "Could not verify the main-system schema. Check the local connection and database setup."
        try:
            data["history_schema"] = "ready" if self.history_store.ready() else "missing_tables"
        except Exception:
            data["history_schema"] = "unavailable"
        data["history_default"] = self.settings.save_history_default
        data["local_planner_enabled"] = self.settings.use_local_planner
        return data

    def catalog(self) -> dict:
        return {
            "api_version": "v1",
            "supported_queries": [
                "asset counts and filtered counts", "counts by location, region, department, employee, type or status",
                "asset lookup by asset number, tag or serial number", "current assignments and assignment counts",
                "warranty end-date lists and date ranges", "asset history by asset identifier",
                "asset transfers", "recorded purchase-cost summaries", "monthly acquisition counts or recorded cost",
                "approved project-document questions with source citations",
            ],
            "database_tables": ["dbo.Assets", "dbo.AssetAssignments", "dbo.AssetHistory", "dbo.AssetTransfers", "dbo.Employees", "dbo.Departments", "dbo.Locations", "dbo.Storerooms"],
            "sql_safety": "fixed allowlisted query templates; parameterized values; no model-generated SQL",
            "history": "owner-scoped in the assistant schema; opt-in per conversation; deletion supported",
        }

    def _load_state(self, conversation_id: str) -> dict[str, Any]:
        with self._lock:
            if conversation_id in self._memory:
                return self._memory[conversation_id]
        loaded = None
        try:
            if self.history_store.ready():
                loaded = self.history_store.load(self.settings.local_user_id, conversation_id)
        except Exception:
            loaded = None
        if loaded:
            context = loaded.get("context") or {}
            state = {
                "conversation_id": conversation_id,
                "title": loaded.get("title") or "Conversation",
                "saved": True,
                "saving_enabled": bool(loaded.get("save_history")),
                "messages": loaded.get("messages", []),
                "last_plan": context.get("last_plan"),
            }
        else:
            state = {"conversation_id": conversation_id, "title": "", "saved": False, "saving_enabled": False, "messages": [], "last_plan": None}
        with self._lock:
            self._memory[conversation_id] = state
        return state

    @staticmethod
    def _history_message(role: str, content: str, metadata: dict | None = None) -> dict:
        return {"role": role, "content": content, "metadata": metadata or {}}

    def _knowledge(self, question: str) -> tuple[str, list[dict], list[dict]]:
        passages = retrieve(question, self.settings.knowledge_dir)
        if not passages:
            return (
                "I couldn't find relevant approved project guidance. Add current, approved Markdown documents to the knowledge folder. I won't guess policy or process answers.",
                [], [],
            )
        answer = grounded_answer(question, passages, base_url=self.settings.ollama_url, model=self.settings.ollama_model)
        if not answer:
            answer = "The local model is unavailable, so here are the closest approved excerpts:\n\n" + "\n\n".join(f"{p.section}: {p.text}" for p in passages)
        citations = [p.citation() for p in passages]
        evidence = [{"source": p.source, "section": p.section, "match_score": p.score} for p in passages]
        return answer, citations, evidence

    def chat(self, payload: dict) -> dict:
        message = payload.get("message")
        if not isinstance(message, str) or not message.strip():
            raise ValueError("Enter a message before sending.")
        if len(message) > 4000:
            raise ValueError("Messages must be 4,000 characters or fewer.")
        save_history = payload.get("save_history", self.settings.save_history_default)
        if not isinstance(save_history, bool):
            raise ValueError("save_history must be true or false.")
        requested_id = payload.get("conversation_id")
        if requested_id:
            try:
                conversation_id = str(uuid.UUID(str(requested_id)))
            except (ValueError, TypeError, AttributeError):
                raise ValueError("conversation_id must be a valid conversation ID returned by this API.")
        else:
            conversation_id = str(uuid.uuid4())
        state = self._load_state(conversation_id)
        question = message.strip()
        previous_plan = deepcopy(state.get("last_plan"))

        plan = make_plan(
            question, previous_plan, use_local_model=self.settings.use_local_planner,
            ollama_url=self.settings.ollama_url, ollama_model=self.settings.ollama_model,
        )
        rows: list[dict] = []
        chart = None
        evidence: list[dict] = []
        citations: list[dict] = []
        warning = None
        result = None

        if plan.get("intent") == "smalltalk":
            answer = "Hi! Ask me about the mock asset records, assignments, warranties, history, transfers, costs, or approved project documents."
        elif plan.get("intent") == "knowledge":
            answer, citations, evidence = self._knowledge(question)
            result = "knowledge"
        elif plan.get("needs_clarification"):
            answer = plan.get("clarifying_question") or "Could you clarify which asset, location, or time period you mean?"
        elif plan.get("intent") == "unsupported":
            answer = "I couldn't map that to an approved asset-data question or approved project document. Try asking for an asset count, lookup, location/department breakdown, assignments, warranty dates, asset history, transfers, or recorded purchase costs."
        else:
            # Every structured answer must be grounded in the configured SQL Server mock database.
            if not self.settings.asset_db:
                raise DatabaseUnavailable("Asset database is not configured. Set ASSET_DB_CONNECTION_STRING in .env and run the local mock-database setup.")
            try:
                query = build_query(plan)
            except ValueError as exc:
                answer = str(exc)
                plan["needs_clarification"] = True
            else:
                try:
                    rows = self.asset_db.query(query.sql, query.params)
                except DatabaseUnavailable:
                    raise
                except Exception as exc:
                    raise DatabaseUnavailable("The approved query could not run against the mock database. Check the database schema and connection.") from exc
                answer = summarize(plan, rows)
                citations = [{"source": source, "section": "read-only query result"} for source in query.sources]
                evidence = [{"query": query.label, "tables": list(query.sources), "filters": plan.get("filters", {}), "row_count": len(rows)}]
                chart = chart_for(plan, rows)
                result = query.label
                if plan.get("intent") in {"assignment_search", "assignment_count"} or plan.get("filters", {}).get("assigned") is True:
                    warning = "Active assignment records are determined from dbo.AssetAssignments where ReturnedAt is NULL. The supplied mock set has limited assignment/history coverage; verify edge cases against direct SQL."
                elif plan.get("intent") in {"history_search", "transfer_search"}:
                    warning = "The supplied mock set has very limited history/transfer rows. No result means no matching seeded row, not proof that the real system has no such event."
                elif plan.get("intent") in {"asset_count", "asset_breakdown", "asset_search", "asset_detail", "warranty_search", "cost_summary", "acquisition_trend"}:
                    warning = "This answer reflects the supplied mock records only, not production data. Missing or inconsistent mock fields may limit the result."

        # Keep bounded in-memory context regardless of saving; only persist if the user enabled it.
        user_entry = self._history_message("user", question)
        assistant_meta = {"plan": plan, "citations": citations, "evidence": evidence, "rows": rows, "chart": chart, "warning": warning}
        assistant_entry = self._history_message("assistant", answer, assistant_meta)
        with self._lock:
            existing_messages = list(state.get("messages", []))
            state["messages"] = (existing_messages + [user_entry, assistant_entry])[-20:]
            state["last_plan"] = plan
            if not state.get("title"):
                state["title"] = question[:180]
            self._memory[conversation_id] = state

        history_warning = None
        history_store_ready = self.history_store.ready() if self.settings.history_connection else False
        if save_history:
            if not history_store_ready:
                history_warning = "History was not saved because the assistant schema is unavailable. Run database/02_assistant_schema.sql and verify database permissions."
            else:
                try:
                    context = {"last_plan": plan}
                    if state.get("saved"):
                        self.history_store.append_turn(
                            owner=self.settings.local_user_id, conversation_id=conversation_id,
                            context=context, messages=[user_entry, assistant_entry],
                        )
                    else:
                        self.history_store.create(
                            owner=self.settings.local_user_id, conversation_id=conversation_id,
                            title=state["title"], context=context, messages=state["messages"],
                        )
                    state["saved"] = True
                    state["saving_enabled"] = True
                    with self._lock:
                        self._memory[conversation_id] = state
                except HistoryUnavailable as exc:
                    history_warning = str(exc)
        elif state.get("saved") and state.get("saving_enabled"):
            try:
                # Do not persist the plan for a turn the user chose not to save.
                self.history_store.set_saving(self.settings.local_user_id, conversation_id, False, {"last_plan": previous_plan})
                state["saving_enabled"] = False
            except HistoryUnavailable as exc:
                history_warning = str(exc)

        return {
            "conversation_id": conversation_id,
            "answer": answer,
            "intent": plan.get("intent"),
            "result_type": result,
            "plan": plan,
            "rows": rows,
            "chart": chart,
            "citations": citations,
            "evidence": evidence,
            "warning": warning,
            "history": {
                "saved": bool(state.get("saved")),
                "saving_enabled": bool(save_history),
                "warning": history_warning,
            },
        }

    def list_conversations(self) -> list[dict]:
        if not self.history_store.ready():
            raise DatabaseUnavailable("Conversation history is not configured. Run database/02_assistant_schema.sql.")
        return self.history_store.list_for_owner(self.settings.local_user_id)

    def get_conversation(self, conversation_id: str) -> dict | None:
        try:
            normalized = str(uuid.UUID(conversation_id))
        except ValueError:
            return None
        if not self.history_store.ready():
            raise DatabaseUnavailable("Conversation history is not configured. Run database/02_assistant_schema.sql.")
        return self.history_store.load(self.settings.local_user_id, normalized)

    def delete_conversation(self, conversation_id: str) -> bool:
        try:
            normalized = str(uuid.UUID(conversation_id))
        except ValueError:
            return False
        deleted = self.history_store.delete(self.settings.local_user_id, normalized)
        with self._lock:
            self._memory.pop(normalized, None)
        return deleted

(() => {
  const $ = id => document.getElementById(id);
  const form = $('chat-form'), input = $('message-input'), conversation = $('conversation');
  const send = $('send-button'), historyBox = $('history-list'), saveToggle = $('save-history');
  let conversationId = null, busy = false, historyEnabledDefault = false;

  function setNotice(text, kind = '') {
    const el = $('system-notice'); el.textContent = text; el.className = `system-notice ${kind}`;
  }
  function addText(parent, tag, text, className) {
    const node = document.createElement(tag); if (className) node.className = className;
    node.textContent = text; parent.appendChild(node); return node;
  }
  function appendMessage(role, text, data = {}) {
    const row = document.createElement('article'); row.className = `message ${role}${data.error ? ' message-error' : ''}`;
    const avatar = addText(row, 'div', role === 'assistant' ? 'AA' : 'You', 'avatar');
    const body = document.createElement('div'); body.className = 'message-body';
    const bubble = addText(body, 'div', text, 'bubble');
    if (data.rows && data.rows.length) renderTable(body, data.rows);
    if (data.chart) renderChart(body, data.chart);
    if (data.warning) addText(body, 'div', data.warning, 'warning-text');
    if (data.citations && data.citations.length) {
      const citations = document.createElement('div'); citations.className = 'citations';
      citations.textContent = 'Evidence: ' + data.citations.map(c => `${c.source}${c.section ? ' — ' + c.section : ''}`).join(' · ');
      body.appendChild(citations);
    }
    if (data.historyWarning) addText(body, 'div', data.historyWarning, 'warning-text');
    if (data.intent) addText(body, 'div', `Route: ${data.intent}${data.resultType ? ` · ${data.resultType}` : ''}`, 'message-meta');
    row.append(avatar, body); conversation.appendChild(row); conversation.scrollTop = conversation.scrollHeight;
    return row;
  }
  function renderTable(parent, rows) {
    const keys = Object.keys(rows[0] || {}); if (!keys.length) return;
    const wrap = document.createElement('div'); wrap.className = 'data-table-wrap';
    const table = document.createElement('table'); table.className = 'data-table';
    const thead = document.createElement('thead'), tr = document.createElement('tr');
    keys.forEach(k => addText(tr, 'th', k.replace(/([A-Z])/g, ' $1').trim(), ''));
    thead.appendChild(tr); table.appendChild(thead);
    const tbody = document.createElement('tbody');
    rows.slice(0, 50).forEach(item => {
      const row = document.createElement('tr');
      keys.forEach(key => addText(row, 'td', item[key] == null ? '—' : String(item[key]), ''));
      tbody.appendChild(row);
    });
    table.appendChild(tbody); wrap.appendChild(table); parent.appendChild(wrap);
  }
  function renderChart(parent, chart) {
    if (!Array.isArray(chart.labels) || !Array.isArray(chart.values) || !chart.labels.length) return;
    const box = document.createElement('div'); box.className = 'chart';
    addText(box, 'p', chart.title || 'Results chart', 'chart-title');
    const max = Math.max(...chart.values.map(Number), 1);
    chart.labels.slice(0, 20).forEach((label, i) => {
      const row = document.createElement('div'); row.className = 'chart-row';
      addText(row, 'span', label, 'chart-label');
      const track = document.createElement('div'); track.className = 'chart-track'; track.setAttribute('role', 'img');
      track.setAttribute('aria-label', `${label}: ${chart.values[i]}`);
      const bar = document.createElement('div'); bar.className = 'chart-bar';
      bar.style.width = `${Math.max(1, Number(chart.values[i]) / max * 100)}%`; track.appendChild(bar);
      row.appendChild(track);
      addText(row, 'span', Number(chart.values[i]).toLocaleString(undefined, { maximumFractionDigits: 2 }), 'chart-value');
      box.appendChild(row);
    });
    addText(box, 'div', chart.value_label || '', 'message-meta'); parent.appendChild(box);
  }
  function clearConversation() {
    conversation.innerHTML = '';
    const welcome = document.getElementById('welcome-template');
    const div = document.createElement('div'); div.className = 'welcome';
    div.innerHTML = '<div class="welcome-icon">AA</div><h3>Ask about the mock asset records</h3><p>Answers use the main-system-shaped <code>dbo</code> data. Try an asset count, lookup, assignment, warranty, history, transfer, cost, or breakdown question.</p><div class="prompt-grid"><button class="prompt-chip" data-prompt="How many assets do we have?">How many assets?</button><button class="prompt-chip" data-prompt="How many locations do we have?">How many locations?</button><button class="prompt-chip" data-prompt="Show laptops by location">Laptops by location</button><button class="prompt-chip" data-prompt="Show current assignments">Current assignments</button></div>';
    conversation.appendChild(div); conversationId = null; $('view-title').textContent = 'New conversation';
    saveToggle.checked = historyEnabledDefault; updateSaveHint(); bindPromptChips(); input.focus();
  }
  function updateSaveHint() {
    $('save-hint').textContent = saveToggle.checked ? 'On — messages will be saved in the local assistant schema' : 'Off — this chat is temporary';
  }
  async function refreshHealth() {
    try {
      const response = await fetch('/api/v1/health'); const h = await response.json();
      const service = $('service-status');
      const serviceReady = h.asset_database === 'ready' && h.main_schema === 'ready';
      service.innerHTML = `<i></i>${serviceReady ? 'Service ready' : 'Needs setup'}`;
      service.className = `service-status ${serviceReady ? 'ready' : ''}`;
      const pill = $('db-pill');
      const ready = h.asset_database === 'ready' && h.main_schema === 'ready';
      pill.textContent = ready ? `Mock DB: ${h.database_name}` : 'Mock DB not ready';
      pill.className = `pill ${ready ? 'pill-ok' : 'pill-warn'}`;
      if (ready) setNotice(`Connected to ${h.database_name}. ${h.knowledge_documents} approved knowledge document(s); history schema ${h.history_schema}.`, 'ready');
      else setNotice(`${h.database_message || 'Connect and seed the local SQL Server mock database, then restart or refresh this page.'} Asset answers will not be generated without database results.`, 'error');
      historyEnabledDefault = Boolean(h.history_default);
      if (!conversationId) saveToggle.checked = historyEnabledDefault;
      updateSaveHint();
    } catch (_) {
      $('service-status').innerHTML = '<i></i>API unavailable'; $('service-status').className = 'service-status';
      $('db-pill').textContent = 'API unavailable'; $('db-pill').className = 'pill pill-bad';
      setNotice('Could not reach the local API. Start it with python run.py and refresh this page.', 'error');
    }
  }
  async function refreshHistory() {
    try {
      const response = await fetch('/api/v1/conversations');
      if (!response.ok) throw new Error('History schema not ready');
      const data = await response.json(); historyBox.innerHTML = '';
      if (!data.conversations.length) return addText(historyBox, 'p', 'No saved conversations yet.', 'muted small');
      data.conversations.forEach(item => {
        const row = document.createElement('div'); row.className = `history-item${item.ConversationId === conversationId ? ' active' : ''}`;
        const open = document.createElement('button'); open.className = 'history-open'; open.textContent = item.Title || 'Conversation';
        open.title = item.UpdatedAtUtc ? `Updated ${item.UpdatedAtUtc}` : item.Title;
        open.addEventListener('click', () => openConversation(item.ConversationId));
        const del = document.createElement('button'); del.className = 'history-delete'; del.title = 'Delete saved conversation'; del.setAttribute('aria-label', 'Delete saved conversation'); del.textContent = '×';
        del.addEventListener('click', async e => { e.stopPropagation(); if (!confirm('Permanently delete this saved conversation?')) return; await deleteConversation(item.ConversationId); });
        row.append(open, del); historyBox.appendChild(row);
      });
    } catch (_) {
      historyBox.innerHTML = ''; addText(historyBox, 'p', 'Run database/02_assistant_schema.sql to enable history.', 'muted small');
    }
  }
  async function openConversation(id) {
    try {
      const response = await fetch(`/api/v1/conversations/${encodeURIComponent(id)}`);
      const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Could not open conversation.');
      conversationId = data.conversation_id; $('view-title').textContent = data.title || 'Saved conversation';
      saveToggle.checked = Boolean(data.save_history); updateSaveHint(); conversation.innerHTML = '';
      (data.messages || []).forEach(m => {
        const meta = m.metadata || {};
        appendMessage(m.role, m.content, m.role === 'assistant' ? {rows: meta.rows, chart: meta.chart, citations: meta.citations, warning: meta.warning, intent: meta.plan && meta.plan.intent} : {});
      });
      await refreshHistory();
    } catch (error) { setNotice(error.message, 'error'); }
  }
  async function deleteConversation(id) {
    try {
      const r = await fetch(`/api/v1/conversations/${encodeURIComponent(id)}`, {method: 'DELETE'});
      if (!r.ok) throw new Error((await r.json()).error || 'Delete failed.');
      if (conversationId === id) clearConversation();
      await refreshHistory();
    } catch (e) { setNotice(e.message, 'error'); }
  }
  async function submitMessage(value = input.value) {
    const message = value.trim(); if (!message || busy) return;
    busy = true; send.disabled = true; $('welcome')?.remove();
    appendMessage('user', message); input.value = ''; input.style.height = 'auto'; $('char-count').textContent = '0 / 4000';
    const pending = appendMessage('assistant', 'Working from the approved data…');
    try {
      const response = await fetch('/api/v1/chat', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message,conversation_id:conversationId,save_history:saveToggle.checked})});
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'The assistant request failed.');
      conversationId = data.conversation_id; $('view-title').textContent = 'Conversation'; pending.remove();
      appendMessage('assistant', data.answer, {rows:data.rows,chart:data.chart,citations:data.citations,warning:data.warning,historyWarning:data.history && data.history.warning,intent:data.intent,resultType:data.result_type});
      await refreshHistory();
    } catch (error) {
      pending.remove(); appendMessage('assistant', error.message, {error:true});
    } finally { busy=false; send.disabled=false; input.focus(); }
  }
  function bindPromptChips() { document.querySelectorAll('.prompt-chip').forEach(btn => btn.onclick = () => submitMessage(btn.dataset.prompt)); }
  $('new-chat').addEventListener('click', clearConversation);
  $('refresh-history').addEventListener('click', refreshHistory);
  saveToggle.addEventListener('change', updateSaveHint);
  input.addEventListener('input', () => { input.style.height='auto'; input.style.height=`${Math.min(input.scrollHeight,130)}px`; $('char-count').textContent=`${input.value.length} / 4000`; });
  input.addEventListener('keydown', e => { if (e.key==='Enter' && !e.shiftKey) {e.preventDefault(); form.requestSubmit();} });
  form.addEventListener('submit', e => {e.preventDefault(); submitMessage();});
  bindPromptChips(); refreshHealth(); refreshHistory();
})();
